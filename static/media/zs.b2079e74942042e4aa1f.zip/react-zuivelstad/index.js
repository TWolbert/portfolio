const express = require("express");
const app = express();
const bodyParser = require("body-parser");
const path = require('path')
const fs = require('fs');
const crypto = require('crypto');
app.use(bodyParser.json());


app.post("/cart", (req, res) => {
  const cart = req.body.cart;
  let uuid = crypto.randomUUID();
  fs.writeFileSync(path.join(__dirname, uuid + ".json"), JSON.stringify(cart));
  console.log("Cart saved to file: " + uuid + ".json")
  res.sendStatus(200)
});

app.listen(3000, () => {
  console.log("Server listening on port 3000");
});

// Serve the static files from the React app's build directory
app.use(express.static(path.join(__dirname, "build")));

// Serve the index.html file for any other requests
app.get("*", (req, res) => {
  res.sendFile(path.join(__dirname, "build", "index.html"));
});