import './webshop.css'
import { Link } from 'react-router-dom';

export default function webshop() {
    function search(e) {
        // Get the value of the searchbar
        try {
          let searchbar = document.getElementById("searchbar").value;
                  // Get all the products
        let products = document.getElementsByClassName("productholder");
        if (searchbar === "") { 
            // If the searchbar is empty, show all the products
            for (let i = 0; i < products.length; i++) {
                products[i].style.display = "block";
            }
            return;
        }
        // Loop through all the products
        for (let i = 0; i < products.length; i++) {
          // Get the name of the product
          let name = products[i].getElementsByClassName("productname")[0].innerHTML;
          // If the name of the product contains the value of the searchbar, show it
          if (name.toLowerCase().includes(searchbar.toLowerCase())) {
            products[i].style.display = "block";
          }
          // If the name of the product does not contain the value of the searchbar, hide it
          else {
            products[i].style.display = "none";
          }
        }
        }
        catch { }

      }
      setInterval(() => {
        search( { keyCode: 0 })
      }, 100);
    return (
        <div className="webshop">
            <div id="webshopheader">
            <h1>Webshop</h1>
            </div>
            <input type="text" id="searchbar" placeholder="Zoek een product" onKeyDown={search}/>
            <div id="Productwrapper">
                <Product pid="1" name="Noten" price="1.99" image="https://media.discordapp.net/attachments/1016275156924116993/1070074834530345010/notenbgremoved.png" />
                <Product pid="2" name="Vanille vla" price="2.99" image="https://media.discordapp.net/attachments/1016275156924116993/1070074834836537505/Vanille-vla.png" />
                <Product pid="3" name="Worst" price="1.99" image="https://media.discordapp.net/attachments/1016275156924116993/1070074835167891537/Worstremovebg.png" />
                <Product pid="4" name="Cashewnoten" price="4.50" image="https://media.discordapp.net/attachments/1016275156924116993/1070074835448905918/cashenotenbgremoved.png" />
                <Product pid="5" name="Chocolade vla" price="4.99" image="https://media.discordapp.net/attachments/1016275156924116993/1070074835721539584/choclade-vla-test.png" />
                <Product pid="6" name="Jonge kaas" price="4.20" image="https://media.discordapp.net/attachments/1016275156924116993/1070075583389761597/jongekaas-removebg-preview.png" />
                <Product pid="7" name="Kaas" price="3.50" image="https://media.discordapp.net/attachments/1016275156924116993/1070074836405211218/kaaksjyhtgfre.png" />
                <Product pid="8" name="Karnemelk" price="0.80" image="https://media.discordapp.net/attachments/1016275156924116993/1070074836598136842/Karameje-removebg-preview.png" />
                <Product pid="9" name="Melk" price="1.20" image="https://media.discordapp.net/attachments/1016275156924116993/1070074836828831754/Melk.png" />
                <Product pid="10" name="Rook worst" price="3.99" image="https://media.discordapp.net/attachments/1016275156924116993/1070074861407449250/rookworst.png" />
                <Product pid="11" name="Oude kaas" price="2.99" image="https://media.discordapp.net/attachments/1016275156924116993/1070074861654904862/oudekaas.png" />
                <Product pid="12" name="Geitenkaas" price="3.99" image="https://media.discordapp.net/attachments/1016275156924116993/1070070480314323066/Geitenkaas.png" />
            </div>
        </div>
    );
 }
const Product = (props) => { 
    let name = props.name;
    let price = props.price;
    let image = props.image;
    let nname = name.replace(" ", "-");
    let link = "/webshop/" + nname + '_' + price;
    return (
        <div className="productholder">
        <h1 className="productname">{name}</h1>
        <img src={image} alt="product" /><br></br>
        <div id="priceholder">
        <Link to={link}>${price}</Link>
        </div>
    </div>
    ) 

}