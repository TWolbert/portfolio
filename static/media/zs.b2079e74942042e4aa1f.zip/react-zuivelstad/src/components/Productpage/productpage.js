import './productpage.css';
import React, { useState } from 'react';
import {Helmet} from "react-helmet";

function Productpage(props) {
    function getimage(name) {
        const images = {
            "Noten": "https://media.discordapp.net/attachments/1016275156924116993/1070074834530345010/notenbgremoved.png",
            "Vanille-vla": "https://media.discordapp.net/attachments/1016275156924116993/1070074834836537505/Vanille-vla.png",
            "Worst": "https://media.discordapp.net/attachments/1016275156924116993/1070074835167891537/Worstremovebg.png",
            "Cashewnoten": "https://media.discordapp.net/attachments/1016275156924116993/1070074835448905918/cashenotenbgremoved.png",
            "Chocolade-vla": "https://media.discordapp.net/attachments/1016275156924116993/1070074835721539584/choclade-vla-test.png",
            "Jonge-kaas": "https://media.discordapp.net/attachments/1016275156924116993/1070075583389761597/jongekaas-removebg-preview.png",
            "Kaas": "https://media.discordapp.net/attachments/1016275156924116993/1070074836405211218/kaaksjyhtgfre.png",
            "Karnemelk": "https://media.discordapp.net/attachments/1016275156924116993/1070074836598136842/Karameje-removebg-preview.png",
            "Melk": "https://media.discordapp.net/attachments/1016275156924116993/1070074836828831754/Melk.png",
            "Rook-worst": "https://media.discordapp.net/attachments/1016275156924116993/1070074861407449250/rookworst.png",
            "Oude-kaas": "https://media.discordapp.net/attachments/1016275156924116993/1070074861654904862/oudekaas.png",
            "Geitenkaas": "https://media.discordapp.net/attachments/1016275156924116993/1070070480314323066/Geitenkaas.png"
        };
        return images[name] || null;
    }
    const buy = () => { 
        let id = props.pid;
        let name = id.split("_")[0];
        let price = id.split("_")[1];
        let image = getimage(name)
        let product = {
            name: name,
            price: price,
            image: image
        }
        let cart = JSON.parse(localStorage.getItem("cart"));
        if (cart == null) {
            cart = [];
        }
        let productAlreadyExists = cart.some(item => item.name === name && item.price === price && item.image === image);
        if (!productAlreadyExists) {
            cart.push(product);
            localStorage.setItem("cart", JSON.stringify(cart));
            setSubmitted(true);
            setTimeout(() => setSubmitted(false), 3000);
        }
    }
    const [submitted, setSubmitted] = useState(false);

    let id = props.pid;
    let name = id.split("_")[0];
    let price = id.split("_")[1];
    let image = getimage(name)
    return (
        <div className="productpage"> 
        <Helmet>
            <meta charSet="utf-8" />
                <title>{name}</title>
        </Helmet>
        {submitted && <div id="Submitkey">Toegevoegd!</div>}
        <div id="infoholder">
        <img src={image} alt="product" id="productimage"/>
        <div id="header">
        <h1 id="ProductTitle">{name}</h1>
        <h5><i id="pricesholder">{price}</i></h5>
        <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Duis laoreet magna nec purus molestie ultrices. Proin tincidunt et diam sit amet convallis. Donec sit amet purus nibh. Proin mauris nisi, rhoncus sed nisi sit amet, congue congue nisl. Donec auctor erat ac sem varius, sit amet dictum enim malesuada. Nam pretium, leo ac bibendum consequat, dolor nulla sollicitudin libero, eget dignissim urna justo eget nulla. Nulla ipsum felis, pulvinar id efficitur vitae, sollicitudin ac arcu. Morbi accumsan egestas urna, id imperdiet enim consequat ut. Fusce blandit nisl ac dolor pulvinar imperdiet. Sed nibh sapien, condimentum et diam et, elementum venenatis sem. Duis et aliquam lectus, vel faucibus eros. Maecenas feugiat tincidunt tempus. Praesent ut nisi pulvinar, elementum lacus non, tempor sapien. Curabitur a massa sit amet mauris elementum cursus eu id arcu. Fusce malesuada arcu eget laoreet euismod.</p>
        <button id="buyb" onClick={buy}>In winkelwagen</button>
        </div>
        </div>
        </div>
    )
}
export default Productpage;