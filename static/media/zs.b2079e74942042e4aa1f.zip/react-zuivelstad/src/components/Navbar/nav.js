import { Link } from 'react-router-dom';
import './navbar.css'
import '../../global.css'
import logo from './images/logo.png';
import cart from './images/cart.png'
import twitter from './images/twitter.webp'

export default function navbar() {
    return (
        <div className="navigation">
            <ul>
                <li><Link to="/"><img src={logo}></img></Link></li>
                <li><a href='https://twitter.com/trilinisty'><img src={twitter}></img></a></li>
                <li><Link to="/cart"><img src={cart}></img></Link></li>
            </ul>
        </div>
    );
}