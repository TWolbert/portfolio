import './cart.css';
import React, { useState } from 'react';

export default function Cart() {
    function getcart() {
        let cart = JSON.parse(localStorage.getItem("cart"));
        if (cart === null) {
            cart = [];
        }
        return cart;
    }
    let cartitems = getcart();
    function itemstoarray() {
        let items = [];
        for (let i = 0; i < cartitems.length; i++) {
            items.push(<CartItem name={cartitems[i].name} price={cartitems[i].price} />);
        }
        return items;
    }
    let items = itemstoarray();
    const [price, setPrice] = useState(0);
    setInterval(() => {
        setPrice(calcprice());
    }, 100);

    async function postCartToServer() {
        const cart = JSON.parse(localStorage.getItem("cart"));
        const response = await fetch("/cart", {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
          },
          body: JSON.stringify({ cart }),
        });
        if (!response.ok) {
          throw new Error("Failed to post cart to server");
        }
        localStorage.removeItem("cart");
        window.location.href = "/";
      }
    
    function calcprice() {
        let cprice = 0;
        const elements = document.getElementsByClassName('amn');
        let values = [];
        for (let i = 0; i < elements.length; i++) {
            values.push(elements[i].innerHTML);
        }
        for (let i = 0; i < cartitems.length; i++) {
            cprice += parseFloat(cartitems[i].price) * parseInt(values[i]);
        }
        return cprice;
    }
    return (
        <div className="Cart">
        <h1>Winkelwagen</h1>
        <div id="cartholder">
        <div id='cartitemholden'>
            {items}
        </div>
        <div id="infowrapper">
        <div id="cartinfo">
            <h2>Bestelling</h2>
            <p>Subtotaal: ${price.toFixed(2)}</p>
            <button id="cobtn" onClick={postCartToServer}>Naar betalen</button>
        </div>
        </div>
        </div>
        </div>
    )
}
const CartItem = (props) => { 
    function getimage(name) {
        const images = {
            "Noten": "https://media.discordapp.net/attachments/1016275156924116993/1070074834530345010/notenbgremoved.png",
            "Vanille-vla": "https://media.discordapp.net/attachments/1016275156924116993/1070074834836537505/Vanille-vla.png",
            "Worst": "https://media.discordapp.net/attachments/1016275156924116993/1070074835167891537/Worstremovebg.png",
            "Cashewnoten": "https://media.discordapp.net/attachments/1016275156924116993/1070074835448905918/cashenotenbgremoved.png",
            "Chocolade-vla": "https://media.discordapp.net/attachments/1016275156924116993/1070074835721539584/choclade-vla-test.png",
            "Jonge-kaas": "https://media.discordapp.net/attachments/1016275156924116993/1070075583389761597/jongekaas-removebg-preview.png",
            "Kaas": "https://media.discordapp.net/attachments/1016275156924116993/1070074836405211218/kaaksjyhtgfre.png",
            "Karnemelk": "https://media.discordapp.net/attachments/1016275156924116993/1070074836598136842/Karameje-removebg-preview.png",
            "Melk": "https://media.discordapp.net/attachments/1016275156924116993/1070074836828831754/Melk.png",
            "Rook-worst": "https://media.discordapp.net/attachments/1016275156924116993/1070074861407449250/rookworst.png",
            "Oude-kaas": "https://media.discordapp.net/attachments/1016275156924116993/1070074861654904862/oudekaas.png",
            "Geitenkaas": "https://media.discordapp.net/attachments/1016275156924116993/1070070480314323066/Geitenkaas.png"
        };
        return images[name] || null;
    }
    let img = getimage(props.name);
    return (
        <div className="CartItem">
            <div id="Productinfo">
            <h2>{props.name}</h2>
            <p id="price">{props.price}</p>
            <Counter />
            </div>
            <img src={img} alt="product" />
        </div>
    )
}
const Counter = () => {
    const [count, setCount] = useState(1);
  
    const incrementCount = () => setCount(count + 1);
    const decrementCount = () => {
        if (count > 1) {
          setCount(count - 1);
        }
        else {
            setCount(1);
        }
      };
  
    return (
      <div id="Countholder">
        <button onClick={decrementCount}>-</button>
        <span className='amn'>{count}</span>
        <button onClick={incrementCount}>+</button>
      </div>
    );
  };