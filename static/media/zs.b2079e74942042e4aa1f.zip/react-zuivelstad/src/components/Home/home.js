import './home.css';
import { Link } from 'react-router-dom';
import '../../global.css'
import Webshop from '../Webshop/webshop';

export default function home() {
    return (
        <div className="home">
            <section id="homesection">
                <h1>Zuivel staat bij ons in het hart</h1>
                <div id="pwrapper">
                <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Proin dignissim tellus sapien, eu placerat nunc placerat non. Duis facilisis vulputate leo, sit amet consequat est aliquet sed. Quisque ultrices dui eu quam pulvinar hendrerit. Phasellus faucibus lorem et cursus pharetra. Aliquam posuere tempus mattis. Etiam vel feugiat odio. Fusce suscipit elit sit amet pharetra consectetur. Nulla leo tortor, vulputate semper blandit a, consequat id mauris. Nunc vitae volutpat mauris, sed pretium lorem. Aenean laoreet rutrum facilisis.</p>
                </div>
                <Link id="webshoplink" to='/webshop'>Shop nu!</Link>
            </section>
        </div>
    );
}