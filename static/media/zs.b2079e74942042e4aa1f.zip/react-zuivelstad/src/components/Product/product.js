export default function product(props) {
    let name = props.name;
    let price = props.price; 
    <div className="product">
        <h1>hello</h1>
    </div>
}