import logo from './logo.svg';
import './App.css';
import React from 'react'
import Nav from './components/Navbar/nav';
import { BrowserRouter as Router, Routes, Route,  } from "react-router-dom";
import Home from './components/Home/home';
import Webshop from './components/Webshop/webshop';
import { useParams } from 'react-router-dom';
import Productpage from './components/Productpage/productpage';
import Cart from './components/Cart/Cart';

function Productwrapper() {
  const pid = useParams();
  console.log(pid);
  return Productpage(pid);
}

function App() {
  return (
    <div className="App">
      <nav>
      <Nav />
      </nav>
      <main>
        <Routes>
          <Route exact path='/' element={<Home />} />
          <Route path='/webshop' element={<Webshop />} />
          <Route path='/webshop/:pid' element={<Productwrapper />} />
          <Route path='/cart' element={<Cart />} />
        </Routes>
      </main>
    </div>
  );
}

export default App;
